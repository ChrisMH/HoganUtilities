﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Chris Hogan")]
[assembly: AssemblyProduct("MicrOrm")]
[assembly: AssemblyCopyright("Copyright © Chris Hogan 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.9.0.1")]
[assembly: AssemblyFileVersion("0.9.0.1")]
[assembly: AssemblyInformationalVersion("0.9.0.1")]