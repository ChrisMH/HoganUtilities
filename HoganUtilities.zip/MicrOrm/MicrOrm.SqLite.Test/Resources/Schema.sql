
CREATE TABLE user
(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT
);

