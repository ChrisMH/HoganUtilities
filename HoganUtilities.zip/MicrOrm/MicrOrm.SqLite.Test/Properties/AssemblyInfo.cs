﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.SqLite.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

