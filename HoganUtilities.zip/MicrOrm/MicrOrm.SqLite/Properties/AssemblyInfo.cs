﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.SqLite")]
[assembly: AssemblyDescription("MicrOrm SqLite-Specific Implementation")]
[assembly: AssemblyConfiguration("")]
