﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.SqlServerCe")]
[assembly: AssemblyDescription("MicrOrm SqlServerCe-Specific Implementation")]
[assembly: AssemblyConfiguration("")]
