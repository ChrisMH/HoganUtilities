﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.PostgreSql.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]


