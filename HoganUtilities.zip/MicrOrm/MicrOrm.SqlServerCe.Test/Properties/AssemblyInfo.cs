﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.SqlServerCe.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

