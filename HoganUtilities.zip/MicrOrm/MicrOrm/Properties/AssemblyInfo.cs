﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("MicrOrm")]
[assembly: AssemblyDescription("Database access without the ORM")]
[assembly: AssemblyConfiguration("")]
[assembly: InternalsVisibleTo("MicrOrm.Test")]