﻿namespace MicrOrm
{
    public interface IDatabase : IDataStrategy
    {
    }
}