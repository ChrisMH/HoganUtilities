﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.PostgreSql")]
[assembly: AssemblyDescription("MicrOrm PostgreSql-Specific Implementation")]
[assembly: AssemblyConfiguration("")]
