﻿using System.Reflection;

[assembly: AssemblyTitle("MicrOrm.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
