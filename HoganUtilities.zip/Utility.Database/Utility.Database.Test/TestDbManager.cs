﻿namespace Utility.Database.Test
{
  public class TestDbManager : IDbManager
  {
    public void Create()
    {
      throw new System.NotImplementedException();
    }

    public void Destroy()
    {
      throw new System.NotImplementedException();
    }

    public void Seed()
    {
      throw new System.NotImplementedException();
    }

    public IDbDescription Description { get; set; }
  }
}