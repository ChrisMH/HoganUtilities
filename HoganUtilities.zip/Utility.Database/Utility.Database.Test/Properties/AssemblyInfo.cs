﻿using System.Reflection;

[assembly: AssemblyTitle("Utility.Database.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]