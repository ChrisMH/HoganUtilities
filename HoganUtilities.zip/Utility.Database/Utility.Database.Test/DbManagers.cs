﻿namespace Utility.Database.Test
{
  public static class DbManagers
  {

    public const string DbManager =
      "<DbManager type=\"Utility.Database.Test.TestDbManager, Utility.Database.Test\">" +
      "<DbDescription type=\"Utility.Database.Test.TestDbDescription, Utility.Database.Test\">" +
      "<Connection>" +
      "<ConnectionStringName>Valid</ConnectionStringName>" +
      "</Connection>" +
      "</DbDescription>" +
      "</DbManager>";
  }
}