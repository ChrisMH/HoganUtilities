﻿namespace Utility.Database.Test
{
  public class TestDbDescription : DbDescription
  {
     
  }
}