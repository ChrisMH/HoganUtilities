﻿using System.Reflection;

[assembly: AssemblyTitle("Utility.Database.MongoDb.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
