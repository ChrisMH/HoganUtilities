using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Utility.Database")]
[assembly: AssemblyCopyright("Copyright � Chris Hogan 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.20.1.1")]
[assembly: AssemblyFileVersion("0.20.1.1")]
[assembly: AssemblyInformationalVersion("0.20.1.1")]