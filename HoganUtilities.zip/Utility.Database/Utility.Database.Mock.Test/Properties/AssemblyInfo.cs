﻿using System.Reflection;

[assembly: AssemblyTitle("Utility.Database.Mock.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]