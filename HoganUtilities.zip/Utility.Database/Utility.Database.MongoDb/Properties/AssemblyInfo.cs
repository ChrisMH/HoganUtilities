﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Utility.Database.MongoDb")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

[assembly: InternalsVisibleTo("Utility.Database.MongoDb.Test")]
