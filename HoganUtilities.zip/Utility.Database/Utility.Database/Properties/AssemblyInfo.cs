﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Utility.Database")]
[assembly: AssemblyDescription("Database Utilities")]
[assembly: AssemblyConfiguration("")]
[assembly: InternalsVisibleTo("Utility.Database.Test")]