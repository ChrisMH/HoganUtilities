﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Utility.Database.PostgreSql")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: InternalsVisibleTo("Utility.Database.PostgreSql.Test")]