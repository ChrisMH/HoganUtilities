﻿INSERT INTO test_schema.test_table (name) VALUES('name1');
INSERT INTO test_schema.test_table (name) VALUES('name2');
