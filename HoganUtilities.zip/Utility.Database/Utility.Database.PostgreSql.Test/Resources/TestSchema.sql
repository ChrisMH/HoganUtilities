﻿CREATE SCHEMA test_schema; 

CREATE TABLE test_schema.test_table 
( 
  id serial NOT NULL, 
  name varchar NOT NULL
);