﻿using System.Reflection;

[assembly: AssemblyTitle("Utility.Database.PostgreSql.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]