﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Utility.Database.Mock")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

[assembly: InternalsVisibleTo("Utility.Database.Mock.Test")]
