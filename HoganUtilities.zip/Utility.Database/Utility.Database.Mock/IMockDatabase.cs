﻿namespace Utility.Database.Mock
{
  public interface IMockDatabase
  {
  }
}