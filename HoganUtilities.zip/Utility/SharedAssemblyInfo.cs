using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Chris Hogan")]
[assembly: AssemblyProduct("Utility")]
[assembly: AssemblyCopyright("Copyright � Chris Hogan 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.7.2.2")]
[assembly: AssemblyFileVersion("0.7.2.2")]
[assembly: AssemblyInformationalVersion("0.7.2.2")]