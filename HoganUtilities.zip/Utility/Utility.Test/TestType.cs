﻿namespace Utility.Test
{
  public class TestType
  {
    public TestType()
    {
      
    }

    public TestType(string p1)
    {
      P1 = p1;
    }

    public TestType(string p1, string p2)
    {
      P1 = p1;
      P2 = p2;
    }

    public string P1;
    public string P2;
  }
}