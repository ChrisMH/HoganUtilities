﻿using System.Reflection;

[assembly: AssemblyTitle("Utility.Test")]
[assembly: AssemblyDescription("Tests for the Utility assembly")]
[assembly: AssemblyConfiguration("")]
