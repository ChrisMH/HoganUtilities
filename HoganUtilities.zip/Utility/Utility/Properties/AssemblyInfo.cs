﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Utility")]
[assembly: AssemblyDescription("Utility Classes")]
[assembly: AssemblyConfiguration("")]
[assembly: InternalsVisibleTo("Utility.Test")]